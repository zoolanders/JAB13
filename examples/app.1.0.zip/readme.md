# Application Files

In order for the application to run, you need the following files:

- **application.php**

This is the core php class that extends the base Application class.
Usually it's just a simple class naming

- **application.xml*

Contains the properties and configuration options of the application

- **application.png**

Application icon

- **application_info.png**

Icon displayed in the information page of the application