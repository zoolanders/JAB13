<?php

class DemoController extends AppController {

	public function jab13() {
		echo json_encode('Do Something Cool!');
		return;
	}
}