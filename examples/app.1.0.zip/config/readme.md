Here you can place extra XML files to display extra configuration options
as accordion items in the application configuration.
Used by ZOO for alphaindex and comments