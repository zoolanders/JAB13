Your custom elements should be located in this folder.
You can also use it for overriding any core element and its templates