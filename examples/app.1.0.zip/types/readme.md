The type config files will be saved here.
You can include default types in your app if you want them to be present upon intallation