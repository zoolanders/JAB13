You can have as many templates as you need for you application.
Each template can have different configurations.
Useful if you need your app more than once for your site.