Here you can have the different renderer folders for each type you need.
Mostly, you will use it for the item rendering, but potentially it's possible
to create a render for everything. 
