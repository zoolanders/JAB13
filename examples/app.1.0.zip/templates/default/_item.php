<div class="teaser-item float-left width50">
	<?php
	echo $this->renderer->render('item.teaser', array('view' => $this, 'item' => $item));
	?>
</div>